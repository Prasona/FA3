 insert into Distributor values('SA110','Mobile_Store','Kolkata',1234567890,
'mobstore@gmail.com');

 insert into Distributor values('SA111','Samsung_World','Ranchi',1234567891,
'samworld@ymail.com');

 insert into Distributor values('NO110','Nokia_prio','Delhi',1234567892,'nokprio@gmail.com');

 insert into Distributor values('NO111','Nokia_Dealers','Chandigarh',1234567893,'nokdeal@ymail.com');


 insert into Distributor values('MC110','Micro_World','Bangalore',1234567894,'micwrld@gmail.com');

insert into Distributor values('MC111','Micro_mania','Bokaro',1234567895,'micromania@gmail.com');





 insert into Mobile_Master values('SA100010', 'SamsungS2', 'Samsung', '2008-04-12', 2, 25000, 'SA110');

insert into Mobile_Master values('SA100020', 'SamsungS3', 'Samsung', '2010-03-02', 2, 33000, 'SA110');

 insert into Mobile_Master values('SA100030', 'SamsungACE', 'Samsung', '2009-12-25', 2, 15000, 'SA111');

insert into Mobile_Master values('NO100030', 'NokiaLumiaC2', 'Nokia', '2009-11-25', 2, 25000, 'NO111');

 insert into Mobile_Master values('NO100020', 'NokiaLumiaB2', 'Nokia', '2007-10-15', 2, 22000, 'NO110');

 insert into Mobile_Master values('NO100010', 'NokiaAsha', 'Nokia', '2011-9-18', 2, 6500, 'NO111');

 insert into Mobile_Master values('MC100010', 'Ninja37', 'Micromax', '2010-06-08', 2, 7500, 'MC111');

 insert into Mobile_Master values('MC100020', 'Ninja32', 'Micromax', '2011-08-28', 2, 7500, 'MC111');

 insert into Mobile_Master values('MC100030', 'MicromaxQ5', 'Micromax', '2009-03-20', 2, 4500, 'MC110');




 insert into Mobile_Specification values('SA100010', '5W10H','100gm','Digital', '5inch', 250, 32,'Y', 'Y', 'Y', 'Y', 'Y', '5MP', 'Andriod4S', 8);

 insert into Mobile_Specification values('SA100020', '9W15H','100gm','Digital', '10inch', 550, 32,'Y', 'Y', 'Y', 'Y', 'Y', '5MP', 'Andriod4S', 6);

 insert into Mobile_Specification values('SA100030', '3W5H','50gm','Digital','10inch',200, 16,'Y', 'Y', 'Y', 'Y', 'Y', '3.2MP', 'Andriod1S', 8);

 insert into Mobile_Specification values('NO100030', '8W8H','100gm','Digital', '10inch',500, 32,'Y', 'Y', 'Y', 'Y', 'Y', '5MP', 'SymbianGT', 10);

 insert into Mobile_Specification values('NO100020', '4W8H','50gm','Digital', '10inch',250, 16,'Y', 'Y', 'Y', 'Y', 'Y', '5MP', 'SymbianAT', 10);

 insert into Mobile_Specification values('NO100030', '4W8H','70gm','Digital', '5inch',150, 16,'N', 'Y', 'Y', 'Y', 'Y', '2MP', 'Java', 8);

 insert into Mobile_Specification values('MC100010', '6W8H','100gm','Digital', '10inch',250, 32,'Y', 'Y', 'Y', 'Y', 'Y', '3.2MP', 'Andriod1S', 12);

 insert into Mobile_Specification values('MC100020', '8W6H','150gm','Digital', '8inch',150, 16,'Y', 'Y', 'Y', 'Y', 'Y', '3.2MP', 'Andriod1S', 12);

 insert into Mobile_Specification values('MC100030', '4W4H','250gm','Digital', '4inch',100, 8,'N', 'Y', 'Y', 'Y', 'Y', '2MP', 'Java', 12);




 insert into Customer_Info values('MB10010', 'Debarun', 'Kolkata', 9899554411, 'chattdeb@gmail.com');

 insert into Customer_Info values('MB10020', 'Manish', 'Bokaro', 9899554412,'rajman@ymail.com');

insert into Customer_Info values('MB10030', 'Sameer', 'Bokaro', 9899554413,'sameerwaa@gmail.com');

insert into Customer_Info values('MB10040', 'Sumit', 'Deogarh', 9899554414,'rajsumit@ymail.com');

insert into Customer_Info values('MB10050', 'Rahul', 'Patna', 9899554415, 'sharmarahul@gmail.com');


 insert into Sales_Info values(1002, '2012-01-11', 'SA100020', 33000, 1000,32000, 'MB10010');

 insert into Sales_Info values(1003, '2012-02-19', 'SA100030', 15000, 200,14800, 'MB10030');

 insert into Sales_Info values(1004, '2012-03-30', 'NO100010', 6500, 100, 6400, 'MB10050');

 insert into Sales_Info values(1005, '2012-01-25', 'MC100010', 7500, 50, 7450, 'MB10020');

 insert into Sales_Info values(1006, '2012-02-11', 'SA100010', 25000, 500,24500, 'MB10020');





