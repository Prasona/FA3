
-- Average

select p.department_id,p.department_name,p.department_location from 
pms_department_details p join pms_manager_details x 
on p.department_id=x.department_id group by x.department_id having count(x.department_id)>=4;

select manager_id,manager_name,job,salary from pms_manager_details 
where job in (select job from pms_manager_details group by job having avg(salary)=
(select max(m.c) from (select job,avg(salary) c from pms_manager_details group by job)m));

select product_id,sum(quantity) from pms_manufacturing where availability='yes' 
group by product_id having sum(quantity)>1500;

select department_id,manager_id,manager_name,job,salary from pms_manager_details a
where salary >=(select avg(salary) from pms_manager_details b 
where a.department_id=b.department_id) order by department_id;

select p.product_id,p.product_name,u.unit_id from pms_product p 
join pms_product_unit u
on p.product_id=u.product_id
join pms_unit_details d
on u.unit_id=d.unit_id
where p.product_name like '%milk';

select p.product_name,d.unit_name,d.total_pieces,d.unit_weight from pms_product p 
join pms_product_unit u
on p.product_id=u.product_id
join pms_unit_details d
on u.unit_id=d.unit_id order by d.unit_weight;

select p.product_id,p.product_name,p.department_id,count(m.unit_id) as NUMBER_OF_VARIETIES
from pms_product p
join pms_manufacturing m
on p.product_id=m.product_id
join pms_unit_details d
on m.unit_id=d.unit_id
where m.product_manfacture_date<='2012-12-15' 
and m.product_expiry_date>='2012-12-15' AND m.availability='yes';

select manager_id,manager_name from pms_manager_details p join pms_department_details d 
on p.department_id=d.department_id
where salary >
(select avg(salary) from pms_manager_details where d.department_location<>'ongole');

select manager_id,manager_name,job,salary from pms_manager_details 
where salary >
(select max(salary) from pms_manager_details where department_id=(
select department_id from pms_manager_details group by department_id 
having count(department_id)=(select max(m.e) from 
(select count(department_id) e from pms_manager_details group by department_id)m)));

select department_id,department_name from pms_department_details where department_id 
not in(select department_id from pms_manager_details group by department_id);

