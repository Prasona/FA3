create database cms;

use cms;


CREATE TABLE PMS_DEPARTMENT_DETAILS
(DEPARTMENT_ID INT(2)PRIMARY KEY,DEPARTMENT_NAME VARCHAR(30)NOT NULL,
DEPARTMENT_LOCATION VARCHAR(30)NOT NULL,DEPARTMENT_EXTENSION INT(3) NOT NULL);
-- PMS_MANAGER_DETAILS TABLE

CREATE TABLE PMS_MANAGER_DETAILS
(Manager_ID INT(5) PRIMARY KEY,Manager_Name VARCHAR(30) NOT NULL,
Job VARCHAR(30) NOT NULL,Boss_Code INT(5),Salary BIGINT NOT NULL,
Commission INT(5),DEPARTMENT_ID INT(2));
-- PMS_UNIT_DETAILS TABLE

CREATE TABLE PMS_UNIT_DETAILS
(UNIT_ID VARCHAR(2) PRIMARY KEY,UNIT_NAME VARCHAR(30) NOT NULL,
PIECE_WEIGHT VARCHAR(15) NOT NULL,TOTAL_PIECES INT(3) NOT NULL,
UNIT_WEIGHT INT NOT NULL);
-- PMS_PRODUCT TABLE

CREATE TABLE PMS_PRODUCT
(PRODUCT_ID VARCHAR(5) PRIMARY KEY,PRODUCT_NAME VARCHAR(30) NOT NULL,
DEPARTMENT_ID INT(2));
-- PMS_PRODUCT_UNIT

CREATE TABLE PMS_PRODUCT_UNIT
(PRODUCT_ID VARCHAR(5),UNIT_ID VARCHAR(2));
-- PMS_MANUFACTURING TABLE

CREATE TABLE PMS_MANUFACTURING
(MANFATURE_ID VARCHAR(5) PRIMARY KEY,PRODUCT_ID VARCHAR(5) NOT NULL,
UNIT_ID VARCHAR(5) NOT NULL,QUANTITY INT(7) NOT NULL,AVAILABILITY VARCHAR(3) NOT NULL,
PRODUCT_MANFACTURE_DATE DATE NOT NULL,PRODUCT_EXPIRY_DATE DATE NOT NULL);
-- Tables created successfully

-- PMS DML STATEMENTS
-- INSERT INTO PMS_DEPARTMENT_DETAILS TABLE
INSERT INTO PMS_DEPARTMENT_DETAILS VALUES(10,'MIS','HYDERABAD_ZONE_1',121);
INSERT INTO PMS_DEPARTMENT_DETAILS VALUES(20,'GHEE SECTION','ONGOLE',122);
INSERT INTO PMS_DEPARTMENT_DETAILS VALUES(30,'PROCESSING SECTION','RAJAMUNDRY',123);
INSERT INTO PMS_DEPARTMENT_DETAILS VALUES(40,'BI_PRODUCTS SECTION','SECUNDERABAD',124);
INSERT INTO PMS_DEPARTMENT_DETAILS VALUES(50,'DISPATCH SECTION','HYDERABAD_ZONE_2',125);
INSERT INTO PMS_DEPARTMENT_DETAILS VALUES(60,'CUSTOMER CARE SECTION','HYDERABAD_ZONE_2',126);
-- INSERT INTO PMS_MANAGER_DETAILS TABLE
INSERT INTO PMS_MANAGER_DETAILS VALUES(7711,'BLAKE','GENERAL MANAGER',NULL,25000,2500,10);
INSERT INTO PMS_MANAGER_DETAILS VALUES(7722,'LARANCE','DEPUTY GENERAL MANAGER',7711,28000,1500,10);
INSERT INTO PMS_MANAGER_DETAILS VALUES(7733,'GATES','MANAGER',7722,26750,500,20);
INSERT INTO PMS_MANAGER_DETAILS VALUES(7744,'CALRK','MANAGER',7722,22000,1000,30);
INSERT INTO PMS_MANAGER_DETAILS VALUES(7755,'VINCY','MANAGER',7722,17500,0,40);
INSERT INTO PMS_MANAGER_DETAILS VALUES(7766,'GALE','MANAGER',7722,16500,0,50);
INSERT INTO PMS_MANAGER_DETAILS VALUES(7770,'NANCY','ASSISTANT MANAGER',7733,30000,500,20);
INSERT INTO PMS_MANAGER_DETAILS VALUES(7771,'GOUD','ASSISTANT MANAGER',7744,23000,750,30);
INSERT INTO PMS_MANAGER_DETAILS VALUES(7772,'NAIDU','ASSISTANT MANAGER',7755,18500,0,40);
INSERT INTO PMS_MANAGER_DETAILS VALUES(7773,'RAO','ASSISTANT MANAGER',7766,15000,3000,50);
INSERT INTO PMS_MANAGER_DETAILS VALUES(7774,'RAJU','ASSISTANT MANAGER',7722,21050,2000,10);
INSERT INTO PMS_MANAGER_DETAILS VALUES(7775,'REDDY','ASSISTANT MANAGER',7722,28500,0,10);
-- INSERT INTO PMS_UNIT_DETAILS TABLE
INSERT INTO PMS_UNIT_DETAILS VALUES('C1','CARTON','235 ML/GMS',20,5);
INSERT INTO PMS_UNIT_DETAILS VALUES('M1','MIN_BOX','25 GMS',20,.5);
INSERT INTO PMS_UNIT_DETAILS VALUES('M2','MAX_BOX','25 GMS',40,1);
INSERT INTO PMS_UNIT_DETAILS VALUES('C2','CAN','19.7 KGS',1,20);
INSERT INTO PMS_UNIT_DETAILS VALUES('T1','TIN','30 GMS',50,1.5);
INSERT INTO PMS_UNIT_DETAILS VALUES('P1','PACK','980 ML',1,1);
INSERT INTO PMS_UNIT_DETAILS VALUES('P2','HALF_PACK','480 ML/GMS',1,0.5);
INSERT INTO PMS_UNIT_DETAILS VALUES('P3','CHOTA_PACK','235 ML/GMS',1,0.25);
-- INSERT INTO PMS_PRODUCT TABLE
INSERT INTO PMS_PRODUCT VALUES('P001','MIXED GHEE',20);
INSERT INTO PMS_PRODUCT VALUES('P002','PANNER',20);
INSERT INTO PMS_PRODUCT VALUES('P003','COOKING BUTTER',20);
INSERT INTO PMS_PRODUCT VALUES('P004','RASAGULLA',40);
INSERT INTO PMS_PRODUCT VALUES('P005','CURD',40);
INSERT INTO PMS_PRODUCT VALUES('P006','DIET MILK',30);
INSERT INTO PMS_PRODUCT VALUES('P007','TONNED MILK',30);
INSERT INTO PMS_PRODUCT VALUES('P008','FAMILY MILK',30);
INSERT INTO PMS_PRODUCT VALUES('P009','STANDERED MILK',30);
INSERT INTO PMS_PRODUCT VALUES('P010','WHOLE MILK',30);
INSERT INTO PMS_PRODUCT VALUES('P011','BUTTER MILK',40);
INSERT INTO PMS_PRODUCT VALUES('P012','DOODH PEDA',40);
INSERT INTO PMS_PRODUCT VALUES('P013','MILK SHAKE',40);
-- INSERT INTO PMS_PRODUCT_UNIT TABLE
INSERT INTO PMS_PRODUCT_UNIT VALUES('P001','C2');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P001','P2');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P001','P3');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P001','P1');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P002','C1');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P002','P1');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P002','P2');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P002','P3');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P006','P1');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P006','P2');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P006','P3');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P007','P1');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P007','P2');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P007','P3');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P008','P1');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P008','P2');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P008','P3');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P009','P1');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P009','P2');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P009','P3');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P010','P1');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P010','P2');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P010','P3');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P003','P2');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P003','P3');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P004','T1');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P005','P3');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P011','P3');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P012','M1');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P012','M2');
INSERT INTO PMS_PRODUCT_UNIT VALUES('P013','C1');
-- INSERT INTO PMS_MANUFACTURING TABLE
INSERT INTO PMS_MANUFACTURING VALUES('M001','P001','C2',100,'YES','2012-08-15','2012-12-15');
INSERT INTO PMS_MANUFACTURING VALUES('M002','P001','P2',500,'YES','2012-08-10','2012-12-15');
INSERT INTO PMS_MANUFACTURING VALUES('M003','P001','P3',250,'YES','2012-08-10','2012-12-15');
INSERT INTO PMS_MANUFACTURING VALUES('M004','P001','P1',300,'NO','2012-08-15','2012-12-15');
INSERT INTO PMS_MANUFACTURING VALUES('M005','P002','C1',190,'YES','2012-08-05','2012-08-31');
INSERT INTO PMS_MANUFACTURING VALUES('M006','P002','P1',500,'YES','2012-08-05','2012-08-31');
INSERT INTO PMS_MANUFACTURING VALUES('M007','P002','P2',250,'YES','2012-08-05','2012-08-31');
INSERT INTO PMS_MANUFACTURING VALUES('M008','P002','P3',500,'YES','2012-08-05','2012-08-31');
INSERT INTO PMS_MANUFACTURING VALUES('M009','P006','P1',4500,'YES','2012-08-15','2012-08-16');
INSERT INTO PMS_MANUFACTURING VALUES('M010','P006','P2',7500,'YES','2012-08-15','2012-08-16');
INSERT INTO PMS_MANUFACTURING VALUES('M011','P006','P3',10000,'YES','2012-08-15','2012-08-16');
INSERT INTO PMS_MANUFACTURING VALUES('M012','P007','P1',4000,'YES','2012-08-15','2012-08-16');
INSERT INTO PMS_MANUFACTURING VALUES('M013','P007','P2',3000,'YES','2012-08-15','2012-08-16');
INSERT INTO PMS_MANUFACTURING VALUES('M014','P007','P3',2500,'YES','2012-08-15','2012-08-16');
INSERT INTO PMS_MANUFACTURING VALUES('M015','P008','P1',7000,'NO','2012-08-15','2012-08-16');
INSERT INTO PMS_MANUFACTURING VALUES('M016','P008','P2',3500,'YES','2012-08-15','2012-08-16');
INSERT INTO PMS_MANUFACTURING VALUES('M017','P008','P3',4500,'YES','2012-08-15','2012-08-16');
INSERT INTO PMS_MANUFACTURING VALUES('M018','P009','P1',1500,'NO','2012-08-15','2012-08-16');
INSERT INTO PMS_MANUFACTURING VALUES('M019','P009','P2',2500,'YES','2012-08-15','2012-08-16');
INSERT INTO PMS_MANUFACTURING VALUES('M020','P009','P3',1000,'YES','2012-08-15','2012-08-16');
INSERT INTO PMS_MANUFACTURING VALUES('M021','P010','P1',10000,'YES','2012-08-15','2012-08-16');
INSERT INTO PMS_MANUFACTURING VALUES('M022','P010','P2',25000,'YES','2012-08-15','2012-08-16');
INSERT INTO PMS_MANUFACTURING VALUES('M023','P010','P3',12500,'YES','2012-08-15','2012-08-16');
INSERT INTO PMS_MANUFACTURING VALUES('M024','P003','P2',2400,'YES','2012-08-10','2012-10-10');
INSERT INTO PMS_MANUFACTURING VALUES('M025','P003','P3',3210,'NO','2012-08-10','2012-10-10');
INSERT INTO PMS_MANUFACTURING VALUES('M026','P004','T1',750,'YES','2012-08-10','2012-12-10');
INSERT INTO PMS_MANUFACTURING VALUES('M027','P005','P3',10000,'YES','2012-08-15','2012-08-17');
INSERT INTO PMS_MANUFACTURING VALUES('M028','P011','P3',27500,'YES','2012-08-15','2012-08-16');
INSERT INTO PMS_MANUFACTURING VALUES('M029','P012','M1',2750,'YES','2012-08-15','2012-08-31');
INSERT INTO PMS_MANUFACTURING VALUES('M030','P012','M2',1850,'NO','2012-08-15','2012-08-31');
INSERT INTO PMS_MANUFACTURING VALUES('M031','P013','C1',1300,'YES','2012-08-10','2012-08-11');

#1.
select a.manager_id,a.manager_name,a.job,b.manager_name as boosname
from pms_manager_details a right outer join pms_manager_details b
on a.boss_code=b.manager_id;

#2
select manager_id,manager_name,job,salary,commission,department_id
from pms_manager_details
where salary=
(select distinct salary from pms_manager_details where job='manager 'order by salary desc limit 1,1);

#3

select manager_id,manager_name,job,salary
from pms_manager_details
where manager_name like '_a%' and salary >
(select salary
from pms_manager_details
where manager_name like 'v%');

#4

select manager_id,manager_name,job, (salary*7.5)*12 as yearly_salary
from pms_manager_details;

#5

select a.manfature_id,a.unit_id,a.product_manfacture_date,a.product_expiry_date,
a.quantity,b.product_name
from pms_manufacturing a inner join pms_product b
on a.product_id=b.product_id
where  department_id='20';


#6

select sum(quantity) as quantity
from pms_manufacturing
group by quantity;

#7

select product_id
from pms_manufacturing
#where product_manfacture_date <= '2012-12-15' 
-- and 
where product_expiry_date ='2012-12-15' 
and availability='yes';


#8

select count(product_id) as COUNT_PRODUCT
from pms_manufacturing
where product_expiry_date ='2012-12-15' 
and availability='no';

#9

select manager_id,manager_name from pms_manager_details
where job!='manager' and salary >
(select avg(salary) from pms_manager_details where job='manager' );

#10

select manager_id,
concat(upper(substring(manager_name,1,1)) , lower(substring(manager_name,2))) as manager_name,
department_id
from pms_manager_details
where salary>20000
order by department_id;

#5


select b.manfature_id,b.unit_id,b.product_manfacture_date,b.product_expiry_date,
b.quantity,a.product_name
from pms_product a inner join pms_manufacturing b
on a.product_id=b.product_id
inner join pms_department_details c
on a.department_id=c.department_id
where department_name='GHEE SECTION';

#AVG

#1

select a.department_id,a.department_name
from pms_department_details a inner join pms_manager_details b
on a.department_id=b.department_id
group by a.department_name having count(b.manager_id)>=4;


#2

select manager_id,manager_name,job,avg(salary) as salary
from pms_manager_details
group by job
having salary =
(select distinct avg(salary) as salary
from pms_manager_details
group by job order by salary desc limit 0,1);

#3

select * 
from pms_manager_details a inner join 
(select department_id,avg(salary) as avgsalary 
from pms_manager_details group by department_id) b
on a.department_id=b.department_id
where a.salary>b.avgsalary;

#4

select b.product_id,b.product_name,c.unit_id,c.unit_name
from pms_product_unit a inner join pms_product b
on a.product_id=b.product_id
inner join pms_unit_details c
on a.unit_id=c.unit_id
where b.product_name like '%milk';


#5


select b.product_name,c.unit_name,c.total_pieces,c.unit_weight
from pms_product_unit a inner join pms_product b
on a.product_id=b.product_id
inner join pms_unit_details c
on a.unit_id=c.unit_id;

#6

select product_id,sum(quantity) as total_quantity 
from pms_manufacturing
where availability='yes'
group by product_id
having total_quantity>1500;

#7

select b.product_name,a.product_id,b.department_id,count(a.unit_id) as NOOFVAR
from pms_manufacturing a inner join pms_product b
on a.product_id=b.product_id
where a.availability='yes' and a.product_manfacture_date<='2012-12-15'
and a.product_expiry_date >='2012-12-15'
group by product_id;

#8


select manager_id,manager_name from pms_manager_details where salary >
(select avg(a.salary) as salary
from pms_manager_details a inner join pms_department_details b
on a.department_id=b.department_id
where b.department_location!='ongole');


#9


select manager_id,manager_name from pms_manager_details where salary in
(select max(salary) as salary from pms_manager_details where department_id in
(select department_id from pms_manager_details 
group by department_id having count(manager_id) in
(select max(c.coun) from
(select count(manager_id) as coun
from pms_manager_details
group by department_id)c))); 

#10

select department_name,department_id
from pms_department_details
where department_id not in (select department_id from pms_manager_details);


#complex

#1

select manager_name,manager_id,job,salary,department_id
from pms_manager_details
where salary=
(select distinct salary from pms_manager_details order by salary limit 6,1);

#2

select S.MANAGER_ID,S.MANAGER_NAME,S.JOB,S.SALARY,S.DEPARTMENT_ID,
B.MANAGER_ID,B.MANAGER_NAME,B.SALARY
from pms_manager_details s inner join pms_manager_details  b
on s.boss_code=b.manager_id
where s.salary>b.salary;

#3

select count(product_id),extract(month from product_manfacture_date) as months
from pms_manufacturing
group by product_id;


#4
select product_id,product_name,department_id from pms_product where product_id in
(select product_id from pms_manufacturing group by product_id having sum(quantity) in
(select max(c.quantity) from
(select sum(quantity) as quantity
from pms_manufacturing
group by product_id)c));

#5
select a.product_id,a.product_name,max(b.quantity) as quantity
from pms_product a inner join pms_manufacturing b
on a.product_id=b.product_id
group by product_id;

