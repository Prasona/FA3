-- List the Managers and their respective Boss Names. 
-- In select list we have Manager_ID, Manager_Name, Job, and Boss_Name.
-- Hint: PMS_MANAGER_DETAILS alias as Manager
-- PMS_MANAGER_DETAILS alias as Boss
-- Boss_Name as an alias in the select query.


select a.manager_id,a.manager_name,a.job,
(select a.manager_name from pms_manager_details a join pms_manager_details b on a.manager_id=b.manager_id)
from pms_manager_details a join pms_manager_details b on a.manager_id=b.manager_id;

select manager_name from pms_manager_details where manager_id in 
(select boss_code from pms_manager_details);