use fms;

select * from booking;
select * from booking_details;
select * from flight;
select * from passenger;

-- 1

select passname from passenger where passname like '_i%';


-- 2

select passname from passenger where passdob>=
ALL(select passdob from passenger );


-- 3

select passname,passdob,datediff(curdate(),passdob)/365 age from passenger;


-- 4

select count(flightid) no_of_flights from flight where flightsource='kol' ;


-- 5

select flightsource from flight f1
group by flightsource having count(flightsource)=
(select count(flightdest)from flight f2 where f1.flightsource=f2.flightdest);


-- 6

select flightsource from flight where flightsource not in
(select flightdest from flight);


-- 7

select flightdate from flight where flightid=1 or flightid=4;


-- 8



select b.flightid,count(bd.passid) from booking_details bd 
join booking b on b.bookingid=bd.bookingid group by b.flightid

-- 9
just use datediff function


-- 10

select bookingid from booking_details group by bookingid having count(passid) 
>=ALL(select count(passid) from booking_details group by bookingid);


-- 11

select b.bookingid,sum(ticketcost) TOtal_Fare
from booking b JOIN booking_details bd
ON b.bookingid=bd.bookingid
JOIN flight f
ON b.flightid=f.flightid
GROUP BY b.bookingid;



-- 12

select b.bookingid,sum(case when datediff(current_date,passdob)/365 <60 then ticketcost
else ticketcost*0.5 end) Total_cost from booking b 
JOIN booking_details bd ON b.bookingid=bd.bookingid
JOIN flight f ON b.flightid=f.flightid JOIN passenger p 
ON p.passid=bd.passid GROUP BY b.bookingid;



-- 13

select flightdest from flight group by flightdest having count(flightid)
>=ALL(select count(flightid) from flight group by flightdest);


-- 14

select passname from passenger where passid in
(select passid from booking_details group by passid having count(bookingid)>1);


-- 15

select b.flightid, count(bd.bookingid) from booking_details bd
join booking b on b.bookingid=bd.bookingid
group by b.flightid;


-- 16

select f.flightid,p.passname from flight f join booking b 
on  f.flightid=b.flightid
join booking_details bd on bd.bookingid= b.bookingid 
join passenger p on p.passid=bd.passid where  b.bookdate=f.flightdate and f.flightid=1;


-- 17

select f1.flightid from flight f1 JOIN flight f2
ON f1.flightid != f2.flightid WHERE f1.flightsource=f2.flightsource
AND f1.flightdest=f2.flightdest;


-- 18



