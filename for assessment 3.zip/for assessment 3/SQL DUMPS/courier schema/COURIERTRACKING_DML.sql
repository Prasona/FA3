
/* ** Insert values in table called COURIER_BRANCH_DETAILS ** */

Insert into COURIER_BRANCH_DETAILS
Values('b01','LINGAMPALLY',256456);

Insert into COURIER_BRANCH_DETAILS
Values('b02','KPHB',256457);

Insert into COURIER_BRANCH_DETAILS
Values('b03','SIRUSERI',256458);

Insert into COURIER_BRANCH_DETAILS
Values('b04','GUNDI',256459);

Insert into COURIER_BRANCH_DETAILS
Values('b05','MGROAD',256460);


Insert into COURIER_BRANCH_DETAILS
Values('b06','GTROAD',256461);

Insert into COURIER_BRANCH_DETAILS
Values('b07','GAJUWAKA',256462);

Insert into COURIER_BRANCH_DETAILS
Values('b08','SRNAGAR',256463);












/* ** Insert values in table called COURIER_CUSTOMER_DETAILS ** */


Insert into  COURIER_CUSTOMER_DETAILS 
Values ('ANIL','LINGAMPALLY','anil@gmail.com',9856412356);


Insert into  COURIER_CUSTOMER_DETAILS 
Values ('SUDHA','SR NAGAR','sudha@yahho.co.in',8965412367);


Insert into  COURIER_CUSTOMER_DETAILS 
Values ('MEHAHA','KPHB COLONY','meha@gmail.com',7456982135);

Insert into  COURIER_CUSTOMER_DETAILS 
Values ('SUNIL','SIRUSERI','sunil@gmail.com',8456246978);

Insert into  COURIER_CUSTOMER_DETAILS 
Values ('LAKSHMI','GUNDI','lakshmi@gmail.com',7569812345);

Insert into  COURIER_CUSTOMER_DETAILS 
Values ('RAHUL','Viswasara','rahul@gmail.com',9647245614);

Insert into  COURIER_CUSTOMER_DETAILS 
Values ('VARMA','KOTHROAD','varma@gmail.com',7654751462);

Insert into  COURIER_CUSTOMER_DETAILS 
Values ('NAVEEN','GAJUWAKA','naveen@gmail.com',7654751461);


/* ** Insert values in table called COURIER_DETAILS ** */


Insert into COURIER_DETAILS Values('C1','CHANDANAGAR','ALLIPURAM','b01','2012-01-12','2012-01-12',50,50,9856412356);


Insert into COURIER_DETAILS Values('C2','CHANDANAGAR','KPHB COLONY','b02','2012-02-10','2012-02-10',10,10,9856412356);


Insert into COURIER_DETAILS Values('C3','AMEERPET','SIRUSERI','b08','2012-02-10','2012-02-13',50,100,8965412367);


Insert into COURIER_DETAILS Values('C4','KPHB COLONY','SIRUSERI','b02','2012-01-05','2012-01-08',65,200,7456982135);


Insert into COURIER_DETAILS Values('C5','GAJUWAKA','KPHBCOLONY','b07','2012-03-05','2012-03-07',35,20,7654751461);


Insert into COURIER_DETAILS Values('C6','GAJUWAKA','SR NAGAR','b07','2012-03-05','2012-03-07',35,20,7654751461);


Insert into COURIER_DETAILS Values('C7','VISWASARA','SRISURI','b03','2012-03-06','2012-03-07',35,20,9647245614);


/* ** Insert values in table called COURIER_STATUS__DETAILS ** */

Insert into COURIER_STATUS_DETAILS
Values('C1','DELIVERED','delivered to the given address','2012-01-14','b07');


Insert into COURIER_STATUS_DETAILS
Values('C2','IN PROCESS','courier delivered to the kphb branch office',null,'b02');

Insert into COURIER_STATUS_DETAILS
Values('C3','DELIVERED','delivered to the given address','2012-02-14','b03');



Insert into COURIER_STATUS_DETAILS
Values('C4','IN PROCESS','unable to find the address so returned back ',null,'b08');

Insert into COURIER_STATUS_DETAILS
Values('C5','DELIVERED','delivered to the given address','2012-03-07','b02');

Insert into COURIER_STATUS_DETAILS
Values('C6','DELIVERED','delivered to the given address','2012-03-09','b08');


Insert into COURIER_STATUS_DETAILS
Values('C7','DELIVERED','delivered to the given address','2012-03-08','b03');




      


