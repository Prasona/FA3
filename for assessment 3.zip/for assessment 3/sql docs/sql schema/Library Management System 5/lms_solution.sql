use lms_db;
set session sql_mode='only_full_group_by';
select  book_code, publication, price,supplier_name from (select book_code, publication, price,supplier_Id
from lms_book_details as bd 
where book_code in(select book_code from lms_book_issue group by book_code 
having count(*)=(select max(cts) from (select BOOK_CODE,COUNT(BOOK_CODE) 'cts' from lms_book_issue group by book_code)x)))y
inner join lms_suppliers_details on lms_suppliers_details.supplier_id=y.supplier_id;

select * from lms_members;
select * from lms_book_details;
select member_id,member_name from lms_members where member_id=(select member_id from lms_book_issue where book_code='BL000002');
select book_code,book_title,author from lms_book_details where author like 'p%';
select count(*) 'NO_OF_BOOKS' from lms_book_details where category='java' group by category;
(select category,count(*) 'NO_OF_BOOKS' from lms_book_details group by category);
select count(*) 'NO_OF_BOOKS' from lms_book_details where publication='Prentice Hall' group by publication;
select book_code,book_title from lms_book_details where book_code in (select book_code from lms_book_issue where date_issue='2012-04-01');
select member_id, member_name, date_register, date_expire from lms_members where date_expire<'2013-04-01';
select member_id, member_name, date_register, membership_status from lms_members where date_register<'2012-03,01' and membership_status='Temporary';
select member_id, member_name 'Name' from lms_members where City in ('CHENNAI','DELHI'); 
select a.book_code,a.publication,a.price,b.supplier_name from lms_book_details a,lms_suppliers_details b where a.book_code in(select max(cts) from (select BOOK_CODE,COUNT(BOOK_CODE) 'cts' from lms_book_issue group by book_code)x) and a.supplier_id=b.supplier_id;
select max(cts) from (select BOOK_CODE,COUNT(BOOK_CODE) 'cts' from lms_book_issue group by book_code)x;
select max(book_code) from lms_book_issue;
select BOOK_CODE,COUNT(BOOK_CODE) 'cts' from lms_book_issue group by book_code;
select concat(Book_Title,'_is_written_by_',Author) 'BOOK_WRITTEN_BY' from lms_book_details;
select * from lms_book_details;
select price from lms_book_details where category='java';
select avg(price) 'avgpric' from (select price from lms_book_details where category='java')x;
select * from lms_suppliers_details;
select supplier_id, supplier_name, email from lms_suppliers_details where email like '%@gmail.com';
select supplier_id, supplier_name, Coalesce((cast(contact as char)),email,address) as 'contact_details' from lms_suppliers_details;
select supplier_id, supplier_name, case 
when contact is null then 'yes'
else 'no'
end from lms_suppliers_details;
select * from lms_book_issue;
select m1.member_id, m1.member_name, m1.city, m1.membership_status,case 
when y.total_sum is null then 0.00
else y.total_sum
end
from lms_members m1 left join (select 
    m.member_id,sum(x.fine_amount) 'total_sum'
from 
    lms_members m 
    inner join 
    (select 
        b.member_id, f.fine_amount 
    from 
        lms_book_issue b 
    inner join  lms_fine_details f on b.fine_range=f.fine_range)x on m.member_id=x.member_id 
group by member_id)y on y.member_id=m1.member_id;

select 
   distinct lm.member_id, lm.member_name, lbi.book_code,lbn.book_title 
from 
    lms_members lm, lms_book_issue lbi, lms_book_details lbn 
where 
    lm.member_id=lbi.member_id and lbi.book_code=lbn.book_code;
    
select * from lms_book_issue;

select * from lms_fine_details;
select * from lms_book_issue;

/*--------------------------------------------------------------------------------------------------*/
select * from lms_members x join    
   (select lmm.member_id,sum(lfd.fine_amount) Fine_Amount from lms_book_issue lbi,lms_fine_details lfd,lms_members lmm
       where lmm.member_id=lbi.member_id and lbi.fine_range=lfd.fine_range
        group by lmm.member_id having sum(lfd.fine_amount)<100)y
        on x.member_id=y.member_id
        join lms_book_issue z
        on x.member_id=z.member_id
        ;



/*------------------------------------------*/
select book_code, book_title, publication, book_edition, price, publish_date from lms_book_details order by extract(YEAR from publish_date), publication, book_edition;

select book_code, book_title,rack_num from lms_book_details where  rack_num='A1' order by book_title;

select 
((select distinct count(book_code) from lms_book_issue where date_returned='2012-05-16')+
(select count(book_code) from lms_book_details where book_code not in(select distinct book_code from lms_book_issue)))
'total_no_of_books_available';

select lm.member_id, lm.member_name, lbi.date_return, lbi.date_returned from lms_members lm, lms_book_issue lbi where lm.member_id=lbi.member_id and lbi.date_return<lbi.date_returned;

select member_id, member_name, date_register  from lms_members where member_id not in(select distinct member_id from lms_book_issue);

select member_id, member_name from lms_members where member_id in(select member_id from lms_book_issue where date_returned>'2012-12-31' or date_returned<'2012-05-05');

select * from lms_book_issue;
select * from lms_book_details;

select date_issue,count(date_issue) 'NOOFBOOKS' from lms_book_issue group by date_issue;
use lms_db;
select book_title, supplier_id from lms_book_details where author='Herbert Schildt' and book_edition='5' and supplier_id='s05';

select rack_num,count(rack_num)'number of books' from lms_book_details group by rack_num order by rack_num;

select lbi.book_issue_no, m.member_name, m.date_register, m.date_expire, lbd.book_title, lbd.author, lbd.price, lbi.date_issue, lbi.date_return, lbi.date_returned, lfd.fine_amount from 
lms_members m inner join lms_book_issue lbi on m.member_id=lbi.member_id
                inner join lms_book_details lbd on lbi.book_code=lbd.book_code
                inner join lms_fine_details lfd on lbi.fine_range=lfd.fine_range;
                
select lbd.book_code, lbd.book_title ,lsd.supplier_name, lbd.price 
            from lms_book_details lbd 
inner join (select max(price) 'price',supplier_id from lms_book_details group by supplier_id)x 
on lbd.supplier_id=x.supplier_id inner join lms_suppliers_details lsd on x.supplier_id=lsd.supplier_id;
select * from lms_book_details;
select lbd.book_code, lbd.book_title,x.price,x.supplier_id,lsd.supplier_name from lms_book_details lbd inner join (select max(price) 'price',supplier_id from lms_book_details group by supplier_id)x 
on lbd.supplier_id=x.supplier_id and lbd.price=x.price inner join lms_suppliers_details lsd on x.supplier_id=lsd.supplier_id;

select book_code, book_title, publication, (datediff(now(),publish_date)/365)'years older' from lms_book_details order by  datediff(now(),publish_date) desc;

select book_code, book_title, supplier_name from lms_book_details lbd join lms_suppliers_details lsd on lbd.supplier_id=lsd.supplier_id
   where lbd.supplier_id= (select 
        supplier_id
    from lms_book_details group by supplier_id 
    having 
        count(supplier_id)=(select max(cts) 
                                from 
                            (select supplier_id, count(supplier_id) 'cts' from lms_book_details group by supplier_id)x));


select supplier_id, supplier_name from lms_suppliers_details where supplier_id=(select 
        supplier_id
    from lms_book_details group by supplier_id 
    having 
        count(supplier_id)=(select min(cts) from
    (select supplier_id, count(supplier_id) 'cts' from lms_book_details group by supplier_id)x));



select * from lms_book_issue;
Insert into LMS_BOOK_ISSUE 
Values (08, 'LM001', 'BL000001', '2012-05-01', '2012-05-16', null, 'R0');


select member_id ,3-count(*) from lms_book_issue where date_returned is null group by member_id
union
select member_id ,3 cnt from lms_members where member_id not in(select  member_id from lms_book_issue 
where date_returned is null);
use lms_db;
select a.member_id,a.member_name,3-count(b.member_id) as remaining_books from lms_book_issue as b 
inner join lms_members as a on a.member_id=b.member_id  where b.date_returned is null group by b.member_id 
union 
select member_id,member_name,3 as remaining_books from lms_members where member_id not in 
(select member_id from lms_book_issue where date_returned is  null) ; 



